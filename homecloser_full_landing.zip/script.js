// Acordeón FAQ (abre uno a la vez)
document.querySelectorAll('.faq details').forEach(d=>{
  d.addEventListener('toggle',()=>{
    if(d.open){
      document.querySelectorAll('.faq details').forEach(o=>{if(o!==d) o.open=false;});
    }
  });
});

// Envío simulado del formulario
document.querySelector('.demo-form')?.addEventListener('submit', (e)=>{
  e.preventDefault();
  alert('¡Gracias! Te contactaremos en 24 h para agendar la demo.');
});
