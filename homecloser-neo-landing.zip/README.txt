HomeCloser — Landing NEO (HTML + Tailwind CDN)

Publicación en Vercel (sin GitHub):
1) Vercel → New Project → Create from scratch.
2) Arrastra este ZIP.
3) Obtendrás la URL (ej. homecloser.vercel.app).

Formulario (Formspree):
- Crea cuenta gratis en https://formspree.io
- Crea un formulario y copia el endpoint (/f/xxxxxxx)
- En index.html reemplaza FORM_ID por tu ID
